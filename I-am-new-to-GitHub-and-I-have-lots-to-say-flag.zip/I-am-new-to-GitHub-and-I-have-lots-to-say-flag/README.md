># I am new to GitHub and I have lots to say
>
> WHY IS THERE CODE??? MAKE A FUCKING .EXE FILE AND GIVE IT TO ME. these dumbfucks think that everyone is a developer and understands code. well i am not and i don't understand it. I only know to download and install applications. SO WHY THE FUCK IS THERE CODE? make an EXE file and give it to me. STUPID FUCKING SMELLY NERDS



[As loudly asked by the community](https://www.reddit.com/r/github/s/BhVD6gIscZ), here is a repo with no code but just a release
with the executable file! Although, since we heard you're all hackers, we went for an elf file...

**Download, execute and get the flag! This time there is no trick, we swear it!**

The Insomni'hack team

